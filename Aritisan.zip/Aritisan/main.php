<?php
$type = $_SESSION['type'];
  if($type=="buyer"){
    echo "
    <div class='w3-main' style='margin-left:300px;margin-top:80px;'>
    <div class='w3-row-padding w3-margin-bottom'>
      <div class='w3-quarter'>
      <a href='bought.php' style='text-decoration: none;'>
      <div class='w3-container w3-blue w3-padding-16'>
          <div class='w3-left'><i class='fa fa-shopping-cart w3-xxxlarge'></i></div>
          <div class='w3-right'>";
          echo countbuys();
          echo "
          </div>
          <div class='w3-clear'></div>
          <h4>Bought Items</h4>
        </div>
      </a>
      </div>
      <div class='w3-quarter'>
      <a href='shipped.php' style='text-decoration: none;'>    
      <div class='w3-container w3-teal w3-padding-16'>
          <div class='w3-left'><i class='fa fa-ship w3-xxxlarge'></i></div>
          <div class='w3-right'>";
            echo countships();
            echo "
          </div>
          <div class='w3-clear'></div>
          <h4>Shipped Items</h4>
        </div>
      </a>
      </div>
    </div>
  </div>
";
}
else{
  echo '
  <div class="w3-main" style="margin-left:300px;margin-top:80px;">
  <div class="w3-row-padding w3-margin-bottom">
    <div class="w3-quarter">
    <a href="sold.php" style="text-decoration: none;">
      <div class="w3-container w3-red w3-padding-16">
        <div class="w3-left"><i class="fa fa-check w3-xxxlarge"></i></div>
        <div class="w3-right">';
        echo countsells();  
        echo '
        </div>
        <div class="w3-clear"></div>
        <h4>Sold Items</h4>
      </div>
    </a>
    </div>
    <div class="w3-quarter">
    <a href="bought.php" style="text-decoration: none;">
    <div class="w3-container w3-blue w3-padding-16">
        <div class="w3-left"><i class="fa fa-shopping-cart w3-xxxlarge"></i></div>
        <div class="w3-right">';
        echo countbuys();
        echo '
        </div>
      <div class="w3-clear"></div>
        <h4>Bought Items</h4>
      </div>
    </a>
    </div>
    <div class="w3-quarter">
    <a href="#" style="text-decoration: none;">    
    <div class="w3-container w3-teal w3-padding-16">
        <div class="w3-left"><i class="fa fa-list w3-xxxlarge"></i></div>
        <div class="w3-right">';
        echo countitmes();
        echo '  
        </div>
        <div class="w3-clear"></div>
        <h4>Total Items</h4>
      </div>
    </a>
    </div>
    <div class="w3-quarter">
    <a href="feedbacks.php" style="text-decoration: none;">  
    <div class="w3-container w3-orange w3-text-white w3-padding-16">
        <div class="w3-left"><i class="fa fa-diamond w3-xxxlarge"></i></div>
        <div class="w3-right">';
          echo countfeedbacks();
          echo '
        </div>
        <div class="w3-clear"></div>
        <h4>Feedbacks</h4>
      </div>
    </a>
    </div>
  </div>
</div>
';
} 
?>

<?php
    session_start();
    include "conn.php";
    $uid = $_SESSION['uid'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $itemname = $_POST['itemname'];
        $idd = $_POST['id'];
        $message = $_POST['message'];
        $sql = "INSERT INTO feedbacks(fname,fdes,uid) VALUES('$itemname','$message','$idd')";    
        if ($conn->query($sql) ==TRUE){
                header("location:../seller.php");    
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Feedback not added";
    }    
?>
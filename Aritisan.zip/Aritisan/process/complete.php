  <?php
  session_start();
  include "conn.php";
  $uid=$_SESSION['uid'];
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $install = $_POST['install'];
    $totalp = 0;
    $sql = "SELECT * FROM cart WHERE uid='$uid'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $uid2=$row['uid'];
            $itemid=$row['itemid'];
            if($uid==$uid2){
            $sql4 = "SELECT * FROM items WHERE itemid='$itemid'";
            $result4 = $conn->query($sql4);
            if ($result4->num_rows > 0) {
            while($row4 = $result4->fetch_assoc()) {
            $itemid2=$row4['itemid'];
            $itemprice2=$row4['itemprice'];
            $itemimage2=$row4['itemimage'];
            $itemq ="1";
            $datetoday = date("Y/m/d");
            $totalp += (int)$itemprice2;
            if($install=="Install"){
                $install = "installed";
            }
            else{
                $install = "shipped";
            }
                $sql1 = "INSERT INTO buyitems (byquantity, byprice,bydate,itemid,uid) VALUES('$itemq','$itemprice2','$datetoday','$itemid2','$uid')";
                if ($conn->query($sql1) ==TRUE){
                    $sql2 = "INSERT INTO sellitems (sequantity, seprice,sedate,sestatus,itemid,uid) VALUES('$itemq','$itemprice2','$datetoday','$install','$itemid2','$uid')";
                    if ($conn->query($sql2) ==TRUE){
                        $sql3 = "DELETE FROM cart WHERE itemid='$itemid' AND uid='$uid'";
                        if ($conn->query($sql3) ==TRUE){
                            header("location:../seller.php");    
                        } 
                        else {
                            echo "Error: " . $sql3 . "<br />" . $conn->error. " <br />";
                        }
                    } 
                else {
                        echo "Error: " . $sql2 . "<br />" . $conn->error. " <br />";
                    }
                } 
                else {
                    echo "Error: " . $sql1 . "<br />" . $conn->error. " <br />";
                }
            }
            }
            else {
            echo "<h1 style='color:#f00;'>0 Items</h1>";
            }
            }
        }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Items</h1>";
        }
    $conn->close();
  }
?>
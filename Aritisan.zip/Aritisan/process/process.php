<?php
if(isset($_POST['register_user']))
{register_user();} 
if(isset($_POST['login_user']))
{login_user();} 
if(isset($_POST['add_cat']))
{add_cat();} 
if(isset($_POST['update_profile']))
{update_profile();}
if(isset($_POST['update_info']))
{update_info();}
if(isset($_POST['delete_account']))
{delete_account();}
if(isset($_POST['add_items']))
{add_items();} 

function register_user(){
    include "conn.php";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fname=$_POST['fnameS'];        
        $lname=$_POST['lnameS'];        
        $number=$_POST['numberS'];        
        $email=$_POST['email']; 
        $pass=$_POST['pass']; 
        $uprofile="profile.png";
        $utype="buyer"; 
        $sql = "INSERT INTO users(fname,lname,pnumber,email,pass,uprofile,utype) VALUES('$fname','$lname','$number','$email','$pass','$uprofile','$utype')";    
        if ($conn->query($sql) ==TRUE){
            header("location:../login.php");    
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Account not created";
    }    
}
function login_user(){
    session_start();
    include "conn.php";
    if($_SERVER["REQUEST_METHOD"]== "POST"){   
        $number =$_POST['number'];
        $password = $_POST['password'];
        $que = "SELECT * FROM users WHERE pnumber = '$number' AND pass = '$password'";
            $result = $conn->query($que);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $uid=$row['uid'];
                    $fname = $row['fname'];
                    $lname = $row['lname'];
                    $num = $row['pnumber'];                
                    $email = $row['email'];
                    $pass = $row['pass'];
                    $profile = $row['uprofile'];
                    $type = $row['utype'];
                    if($password==$pass && $number==$num) {  
                     $_SESSION['uid'] = $uid;
                     $_SESSION['fname'] = $fname;
                     $_SESSION['lname'] = $lname;
                     $_SESSION['number'] = $num;
                     $_SESSION['email'] = $email;
                     $_SESSION['password'] =$pass;
                     $_SESSION['profile'] =$profile;
                     $_SESSION['type'] = $type;
                     header("location:../seller.php");                                               
                    }
            }
        } 
        else{
            echo "<script>alert('Sad...! You entered wrong number or password.');window.location.href ='../login.php';</script>";
        }      
        $conn->close();
    }    
 }


 function update_profile(){
    session_start();
    include "conn.php";
    $id=$_SESSION['uid'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $uploads_dir = '../images';
        $temp_name = $_FILES["pimg"]["tmp_name"];
        $name = basename($_FILES["pimg"]["name"]);
        $sql = "UPDATE users SET uprofile = '$name' WHERE uid='$id'";    
        if ($conn->query($sql) ==TRUE){
            if(move_uploaded_file($temp_name, "$uploads_dir/$name")){
                $_SESSION['profile'] = $name;
                header("location:../message2.php");
            }    
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Profile not updated";
    }    
}

function update_info(){
    session_start();
    include "conn.php";
    $id=$_SESSION['uid'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fname=$_POST['fnameS'];        
        $lname=$_POST['lnameS'];        
        $number=$_POST['numberS'];        
        $email=$_POST['email']; 
        $pass=$_POST['pass']; 
        $sql = "UPDATE users SET fname = '$fname', lname = '$lname', pnumber = '$number', email = '$email', pass = '$pass' WHERE uid='$id'";    
        if ($conn->query($sql) ==TRUE){
            $_SESSION['fname'] = $fname;
            $_SESSION['lname'] = $lname;
            $_SESSION['number'] = $number;
            $_SESSION['email'] = $email;
            $_SESSION['password'] =$pass;
            header("location:../message2.php");
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Profile not updated";
    }    
}



function delete_account(){
    session_start();
    include "conn.php";
    $id=$_SESSION['uid'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $sql = "DELETE FROM users WHERE uid='$id'";    
        if ($conn->query($sql) ==TRUE){
                header("location:../message3.php");
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Account not deleted";
    }    
}

 function add_cat(){
    session_start();
    include "conn.php";
    $id = $_SESSION['uid'];
    $uploads_dir = '../images';
    $temp_name = $_FILES["tyimg"]["tmp_name"];
    $name = basename($_FILES["tyimg"]["name"]);
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $tyname=$_POST['tyname'];        
        $tydes=$_POST['tydes'];        
        $sql = "INSERT INTO itemtype(tyname,tydes,tyimg,id) VALUES('$tyname','$tydes','$name','$id')";    
        if ($conn->query($sql) ==TRUE){
            if(move_uploaded_file($temp_name, "$uploads_dir/$name")){
                header("location:../message.php");    
            }
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Category not created";
    }    
}

 
function types()
{
    include "conn.php";
    $sql = "SELECT * FROM itemtype";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $tyid=$row['tyid'];
                $tyname=$row['tyname'];            
                $tydes=$row['tydes'];
                $tyimg=$row['tyimg'];
                echo "
                <div class='col' style='margin-top:3%;'>
                <a href='items.php?id=$tyid && cate=$tyname' style='text-decoration: none;color: #000;'>
                  <div class='card' style='width: 25rem;'>
                    <img src='images/$tyimg' class='card-img-top' alt='...'>
                    <div class='card-body'>
                      <h3>$tyname</h3>
                      <p class='card-text'>$tydes</p>
                      <button class='btn btn-secondary'>Browse Items</button>
                    </div>
                  </div>
                </a>
                </div>
            ";
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Category</h1>";
        }
    $conn->close();
}

function countbuys()
{   
    include "conn.php";
    $id = $_SESSION['uid'];
    $sql = "SELECT COUNT(byid) AS items FROM buyitems WHERE uid='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $items = $row['items'];
                echo "
                <h3>$items</h3>
                ";
        }       
    }
    else {
        echo "<h3>0</h3>";
    }
    $conn->close();
}

function countfeedbacks()
{   
    include "conn.php";
    $id = $_SESSION['uid'];
    $sql = "SELECT COUNT(fid) AS feedbacks FROM feedbacks WHERE uid='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $feedbacks = $row['feedbacks'];
                echo "
                <h3>$feedbacks</h3>
                ";
        }       
    }
    else {
        echo "<h3>0</h3>";
    }
    $conn->close();
}

function countsells()
{   
    include "conn.php";
    $id = $_SESSION['uid'];
    $sql = "SELECT uid, COUNT(DISTINCT itemid) AS sells FROM sellitems WHERE uid='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $uid = $row['uid'];                
                $sells = $row['sells'];
                if($uid==$id){
                    echo "
                    <h3>$sells</h3>
                    ";    
                }
                else{
                    echo "
                    <h3>0</h3>
                    ";    
                }
        }       
    }
    else {
        echo "<h3>0</h3>";
    }
    $conn->close();
}

function countships()
{   
    include "conn.php";
    $id = $_SESSION['uid'];
    $sql = "SELECT uid, COUNT(seid) AS ships FROM sellitems WHERE uid='$id' AND sestatus='shipped'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $uid = $row['uid'];
                $ships = $row['ships'];
                if($uid==$id){
                    echo "
                    <h3>$ships</h3>
                    ";    
                }
                else{
                    echo "
                    <h3>0</h3>
                    ";    
                }
        }       
    }
    else {
        echo "<h3>0</h3>";
    }
    $conn->close();
}

function countitmes()
{   
    include "conn.php";
    $id = $_SESSION['uid'];
    $sql = "SELECT uid, COUNT(itemid) AS itemes FROM items WHERE uid='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $uid = $row['uid'];
                $items = $row['itemes'];
                if($uid==$id){
                    echo "
                    <h3>$items</h3>
                    ";    
                }
                else{
                    echo "
                    <h3>0</h3>
                    ";    
                }
        }       
    }
    else {
        echo "<h3>0</h3>";
    }
    $conn->close();
}



function buy_items()
{
    include "conn.php";
    $id = $_SESSION['uid']; 
    $sql="SELECT t1.itemid, t1.itemimage,t1.itemname, t2.byquantity, t2.byprice, t2.bydate, t2.uid FROM items t1 JOIN buyitems t2 ON t1.itemid=t2.itemid";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $itemid=$row['itemid'];
                $itemimage=$row['itemimage'];            
                $itemname=$row['itemname'];            
                $byquantity=$row['byquantity'];
                $byprice=$row['byprice'];
                $totalprice = (int)$byprice*(int)$byquantity;
                $bydate=$row['bydate'];
                $bystatus="bought";
                $uid=$row['uid'];
                if($uid==$id){
                    echo "
                    <tr>
                    <td><img src='images/$itemimage' class='itemimg' id='$itemid'></td>
                    <td>$byquantity</td>
                    <td>$totalprice$</td>
                    <td>$bydate</td>
                    <td>$bystatus</td>
                    <td><a href='review.php?id=$uid && name=$itemname && price=$byprice' style='text-decoration:none;'><button class='short' style='width: 90%;float:left;'>Feedback <i class='fa fa-diamond'></i></button></a></td>
                   </tr>
                    ";    
                }
                else{
                }
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Items</h1>";
        }
    $conn->close();
}




function sell_items()
{
    include "conn.php";
    $id = $_SESSION['uid']; 
    $sql="SELECT t1.itemid, t1.itemimage, t2.sequantity, t2.seprice, t2.sedate, t2.sestatus,t2.uid FROM items t1 JOIN sellitems t2 ON t1.itemid=t2.itemid";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $itemid=$row['itemid'];
                $itemimage=$row['itemimage'];            
                $sequantity=$row['sequantity'];
                $seprice=$row['seprice'];
                $totalprice = (int)$seprice*(int)$sequantity;
                $sedate=$row['sedate'];
                $sestatus=$row['sestatus'];
                $uid=$row['uid'];
                if($uid==$id){
                echo "
                <tr>
                <td><img src='images/$itemimage' class='itemimg' id='$itemid'></td>
                <td>$sequantity</td>
                <td>$totalprice$</td>
                <td>$sedate</td>
                <td>$sestatus</td>
               </tr>
                ";
                }
                else{}
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Items</h1>";
        }
    $conn->close();
}

function ship_items()
{
    include "conn.php";
    $id = $_SESSION['uid']; 
    $sql="SELECT t1.itemid, t1.itemimage, t2.sequantity, t2.seprice, t2.sedate, t2.sestatus,t2.uid FROM items t1 JOIN sellitems t2 ON t1.itemid=t2.itemid WHERE t2.sestatus='shipped'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $itemid=$row['itemid'];
                $itemimage=$row['itemimage'];            
                $sequantity=$row['sequantity'];
                $seprice=$row['seprice'];
                $totalprice = (int)$seprice*(int)$sequantity;
                $sedate=$row['sedate'];
                $sestatus=$row['sestatus'];
                $uid=$row['uid'];
                if($uid==$id){
                    echo "
                    <tr>
                    <td><img src='images/$itemimage' class='itemimg' id='$itemid'></td>
                    <td>$sequantity</td>
                    <td>$totalprice$</td>
                    <td>$sedate</td>
                    <td>$sestatus</td>
                   </tr>
                    ";    
                }
                else{}
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Items</h1>";
        }
    $conn->close();
}

function install_items()
{
    include "conn.php";
    $id = $_SESSION['uid']; 
    $sql="SELECT t1.itemid, t1.itemimage, t2.sequantity, t2.seprice, t2.sedate, t2.sestatus,t2.uid FROM items t1 JOIN sellitems t2 ON t1.itemid=t2.itemid WHERE t2.sestatus='installed'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $itemid=$row['itemid'];
                $itemimage=$row['itemimage'];            
                $sequantity=$row['sequantity'];
                $seprice=$row['seprice'];
                $totalprice = (int)$seprice*(int)$sequantity;
                $sedate=$row['sedate'];
                $sestatus=$row['sestatus'];
                $uid=$row['uid'];
                if($uid==$id){
                    echo "
                    <tr>
                    <td><img src='images/$itemimage' class='itemimg' id='$itemid'></td>
                    <td>$sequantity</td>
                    <td>$totalprice$</td>
                    <td>$sedate</td>
                    <td>$sestatus</td>
                   </tr>
                    ";    
                }
                else{}
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Items</h1>";
        }
    $conn->close();
}


function showtypes()
{
    include "conn.php";
    $sql = "SELECT * FROM itemtype";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $tyid=$row['tyid'];
                $tyname=$row['tyname'];            
                echo "
                <a href='items.php?id=$tyid && cate=$tyname' style='text-decoration:none;'><li>$tyname | </li></a>
                ";
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Category</h1>";
        }
    $conn->close();
}

function showtypes2()
{
    include "conn.php";
    $sql = "SELECT * FROM itemtype";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $tyid=$row['tyid'];
                $tyname=$row['tyname'];            
                echo "
                <option>$tyname</option>
                ";
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Category</h1>";
        }
    $conn->close();
}

function add_items(){
    session_start();
    include "conn.php";
    $id=$_SESSION['uid'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $uploads_dir = '../images';
        $temp_name = $_FILES["itemimage"]["tmp_name"];
        $name = basename($_FILES["itemimage"]["name"]);
        $itemname=$_POST['itemname'];        
        $itemdes=$_POST['itemdes'];        
        $type=$_POST['type'];        
        $itemprice=$_POST['itemprice']; 
        $itemquantity=$_POST['itemquantity']; 
        $itemcolor=$_POST['itemcolor']; 
        $sql = "INSERT INTO items(itemname,itemdes,itemprice,itemquantity,itemcolor,itemimage,itemcat,uid) VALUES('$itemname','$itemdes','$itemprice','$itemquantity','$itemcolor','$name','$type','$id')";    
        if ($conn->query($sql) ==TRUE){
            if(move_uploaded_file($temp_name, "$uploads_dir/$name")){
                header("location:../message6.php");    
            }
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Item not Added";
    }    
}




function show_feedbacks()
{
    include "conn.php";
    $sql="SELECT * FROM feedbacks";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {            
                $fname=$row['fname'];
                $fdes=$row['fdes'];
                echo "
                <tr>
                <td>$fname</td>
                <td>$fdes</td>
                </tr>
                ";
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Feedbacks</h1>";
        }
    $conn->close();
}


function show_items()
{
    $uid = $_SESSION['uid'];
    $itcat = $_GET['cate'];
    include "conn.php";
    $sql = "SELECT * FROM items WHERE itemcat='$itcat'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $itemid=$row['itemid'];
                $itemname=$row['itemname'];            
                $itemdes=$row['itemdes'];
                $itemprice=$row['itemprice'];
                $itemcolor=$row['itemcolor'];
                $itemimage=$row['itemimage'];
                $utid=$row['uid'];
                echo "
                <div class='col' style='margin-top:3%;' id='$utid'>
                <div class='card' style='width: 25rem;'>
                  <img src='images/$itemimage' class='card-img-top' alt='...'>
                  <div class='card-body'>
                    <h3>$itemname</h3>
                    <div class='row' style='margin-top: 10px;'>
                      <div class='col'>
                        <p class='card-text'>Price: </p>
                      </div>
                      <div class='col'>
                        <p class='card-text'>$itemprice$</p>
                      </div>
                    </div>
                    <div class='row' style='margin-top: 10px;'>
                      <div class='col'>
                        <p class='card-text'>Description: </p>
                      </div>
                      <div class='col'>
                        <p class='card-text'>$itemdes</p>
                      </div>
                    </div>
                    <div class='row' style='margin-top: 10px;'>
                      <div class='col'>
                        <p class='card-text'>Color: </p>
                      </div>
                      <div class='col'>
                        <p class='card-text'>$itemcolor</p>
                      </div>
                    </div>
                    <div class='row w3-center' style='margin-top: 10px;'>
                      <a href='process/add_cart.php?uid=$uid && itemid=$itemid && cate=$itcat' style='text-decoration:none;'><button class='short' style='width: 90%;float:left;'>Add to Cart <i class='fa fa-shopping-cart'></i></button></a>
                    </div>  
                  </div>
                </div>
              </div>
            ";
                }       
    }
    else {
        echo "<h1 style='color:#f00;'>0 Items</h1>";
        }
    $conn->close();
}

function add_cart(){
    session_start();
    include "conn.php";
    $id = $_SESSION['uid'];
    $uploads_dir = '../images';
    $temp_name = $_FILES["tyimg"]["tmp_name"];
    $name = basename($_FILES["tyimg"]["name"]);
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $tyname=$_POST['tyname'];        
        $tydes=$_POST['tydes'];        
        $sql = "INSERT INTO itemtype(tyname,tydes,tyimg,id) VALUES('$tyname','$tydes','$name','$id')";    
        if ($conn->query($sql) ==TRUE){
            if(move_uploaded_file($temp_name, "$uploads_dir/$name")){
                header("location:../message.php");    
            }
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Category not created";
    }    
}

function count_cart()
{   
    include "conn.php";
    $id = $_SESSION['uid'];
    $sql = "SELECT COUNT(cid) AS cart_item FROM cart WHERE uid='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
                $cart_item = $row['cart_item'];
                echo "$cart_item";
        }       
    }
    else {
        echo "0";
    }
    $conn->close();
}


function show_cart_items()
{
    $uid = $_SESSION['uid'];
    include "conn.php";
    $totalp = 0;
    $sql = "SELECT * FROM cart WHERE uid='$uid'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $uid2=$row['uid'];
            $itemid=$row['itemid'];
            if($uid==$uid2){
            $sql2 = "SELECT * FROM items WHERE itemid='$itemid'";
            $result2 = $conn->query($sql2);
            if ($result2->num_rows > 0) {
            while($row2 = $result2->fetch_assoc()) {
            $itemprice2=$row2['itemprice'];
            $itemimage2=$row2['itemimage'];
            $totalp += (int)$itemprice2;
            echo "
            <div class='row w3-center' style='margin-top: 10px;'>
            <div class='col'>
              <a href='images/$itemimage2' target='_blank'><img src='images/$itemimage2' style='width: 50px;height: 50px;' /></a>
            </div>
            <div class='col'>
              <p>Price: $itemprice2$</p>
            </div>
            <div class='col'>
              <a href='process/delete_cart_item.php?cartid=$itemid' style='text-decoration: none;color:#fff'><button class='seller'>Delete</button></a>
            </div>
            </div>                    
            ";
            }
            }
            else {
            echo "<h1 style='color:#f00;'>0 Items</h1>";
            }
            }
        }       
        echo "
        <div class='row' style='margin:auto;margin-top: 10px;width: 80%;'>
        <center><a href='payment.php?id=$uid && pay=$totalp' style='text-decoration: none;'><button class='seller move'>Proceed to payment</button></a></center>
        </div>        
        ";        

    }

    else {
        echo "<h1 style='color:#f00;'>0 Items</h1>";
        }
    $conn->close();
}

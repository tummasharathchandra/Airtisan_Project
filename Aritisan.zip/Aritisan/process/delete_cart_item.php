<?php
    session_start();
    include "conn.php";
    $id=$_GET['cartid'];
    $uid1=$_SESSION['uid'];
        $sql = "DELETE FROM cart WHERE itemid='$id' AND uid='$uid1'";    
        if ($conn->query($sql) ==TRUE){
                header("location:../cart.php");
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
?> 
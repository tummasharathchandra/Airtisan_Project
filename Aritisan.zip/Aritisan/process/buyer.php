<?php
    include "conn.php";
    $id = $_GET['id'];
        $sql = "UPDATE users SET utype = 'buyer' WHERE uid='$id'";    
        if ($conn->query($sql) ==TRUE){
                header("location:../message5.php");
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
?>
<?php
    include "conn.php";
    $id = $_GET['id'];
        $sql = "UPDATE users SET utype = 'seller' WHERE uid='$id'";    
        if ($conn->query($sql) ==TRUE){
                header("location:../message4.php");
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
?>
<?php
session_start();
    include "conn.php";
    $uid = $_GET['uid'];
    $itemid = $_GET['itemid'];
    $itemcat = $_GET['cate'];

    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $sql = "INSERT INTO cart(uid,itemid) VALUES('$uid','$itemid')";    
        if ($conn->query($sql) ==TRUE){
                header("location:../items.php?cate=$itemcat");    
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "item not added";
    }    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <?php include "headlinks.php";?>
    </head>
    <body> 
    <div class="row"> 
    <header>
        <div class="row" style="margin-top:-4px;">
        <center>
            <a href="index.php" style="text-decoration:none;color:#fff;"><h3 style="font-variant:small-caps;color:white;">Aritisan</h3></a>
        </center>
        </div>    
    </header>
</div> 
    <div class="row w3-center" style="margin-bottom: 100px;">
        <center>
    <form class="form" autocomplete="off" action="process/process.php" method="post"> 
        <h1>Login</h1> <br />   
        <input type="text" name="number" placeholder="Enter number" required />
        <input type="password" name="password" placeholder="Enter password" required />
        <input type="submit" id="submit" value="Login" name="login_user" />
        <p style="font-size: 0.7em;">New to Aritisan? <a href="signup.php">Sign up</a> </p>
    </form>
    </center>    
    </div> 
</body>
</html>
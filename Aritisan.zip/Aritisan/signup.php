<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign Up</title>
    <?php include "headlinks.php";?>
    </head>
    <body> 
    <div class="row"> 
    <header>
        <div class="row" style="margin-top:-4px;">
        <center>
            <a href="index.php" style="text-decoration:none;color:#fff;"><h3 style="font-variant:small-caps;color:white;">Aritisan</h3></a>
        </center>
        </div>    
    </header>
    </div> 
    <div class="w3-row w3-center" style="margin-bottom: 100px;">
        <center>
        <form class="form" autocomplete="off" action="process/process.php" method="post"> 
        <h1>Register</h1> <br />   
        <input type="text" name="fnameS" id="fname" placeholder="First name" required />
        <input type="text" name="lnameS" id="lname" placeholder="Last name" required />
        <input type="text" name="numberS" id="number" placeholder="Phone Number" required />
        <input type="email" name="email" id="email" placeholder="Email" required />
        <input type="password" name="pass" placeholder="Password" required />
        <input type="submit" id="submit" value="Sign Up" name="register_user" />
        <p style="font-size: 0.7em;">Already have an account? <a href="login.php">Login</a> </p>
        </form>
        </center>    
    </div>
</body>
</html>  
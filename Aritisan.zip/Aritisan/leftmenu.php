<?php
$type = $_SESSION['type'];
$name = $_SESSION['fname'];
$profile = $_SESSION['profile'];
  if($type=="buyer"){
    echo '
    <nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;margin-top: 50px;" id="mySidebar"><br>
    <div class="w3-container w3-row">
      <div class="w3-col s3">
        <img src="images/';echo $profile;echo '" class="w3-margin-right" style="width:50px;height:50px;border-radius:50%;">
      </div>
      <div class="w3-col s9 w3-bar" style="margin-top: 15px;">
      <span>Welcome, <strong>'; echo $name; echo '</strong></span>
      </div>
    </div>
    <hr>
    <div class="w3-container">
      <h5>Dashboard</h5>
    </div>
    <div class="w3-bar-block">
      <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
      <a href="seller.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-users fa-fw"></i>  Overview</a>
      <a href="bought.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-shopping-cart"></i>  Bought items</a>
      <a href="shipped.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-ship"></i>  Shipped items</a>
      <a href="installed.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-lightbulb-o"></i>  Installed items</a>
      <a href="setting.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-cog fa-fw"></i>  Settings</a><br><br>
    </div>
  </nav> 
    ';
}
else{
  echo '
  <nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;margin-top: 50px;" id="mySidebar"><br>
  <div class="w3-container w3-row">
    <div class="w3-col s3">
    <img src="images/';echo $profile;echo '" class="w3-margin-right" style="width:50px;height:50px;border-radius:50%;">
    </div>
    <div class="w3-col s9 w3-bar" style="margin-top: 15px;">
    <span>Welcome, <strong>'; echo $name; echo '</strong></span>
    </div>
  </div>
  <hr>
  <div class="w3-container">
    <h5>Dashboard</h5>
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
    <a href="seller.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-users fa-fw"></i>  Overview</a>
    <a href="sold.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-check"></i>  sold items</a>
    <a href="bought.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-shopping-cart"></i>  Bought items</a>
    <a href="shipped.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-ship"></i>  Shipped items</a>
    <a href="installed.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-lightbulb-o"></i>  Installed items</a>
    <a href="add.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  add item</a>
    <a href="add_item.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  add category</a>
    <a href="feedbacks.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-diamond fa-fw"></i>  feedbacks</a>
    <a href="setting.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-cog fa-fw"></i>  Settings</a><br><br>
  </div>
</nav> 
  ';
} 
?>

<?php 
session_start();
include "process/process.php";
include "switch.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
if (isset($_POST['toggleAccountType'])) {
  $currentAccountType = $_SESSION['type'];
  if ($currentAccountType === 'buyer') {
      $_SESSION['type'] = 'seller';
  } else {
      $_SESSION['type'] = 'buyer';
  }
  echo $_SESSION['type'];
  exit;
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Seller Dashboard</title>
<?php include "headlinks.php";?>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey" onload="showsidebar();hidesidebar();showmenu()"> 
<?php include "header.php";?>
<?php include "leftmenu.php";?>
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<?php include "main.php";?>
    <script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>

<?php
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  echo "
  <div class='w3-row leftmenuhide' id='leftmenuhide'>
  <div class='w3-row'>
      <button class='times' id='times'><i class='fa fa-times'></i></button>
  </div>
  <div class='w3-row'>
  <ul class='sideul'>
    <li><a href='index.php'><i class='fa fa-home' style='font-weight: bold;'></i> Home</a></li>
    <li><a href='shipped.php'>Shipping</a></li>
    <li><a href='search.php'>Search</a></li>
    <li><a href='installed.php'>Installation</a></li>
    <li><a href='about.php'>About us</a></li>
    <li><a href='index.php#Contact'>Contact</a></li>
    <li><a href='login.php'>login</a></li>
</ul>
</div>
</div>
<div class='row'>
<header>
<div class='row'>
<div class='col-sm-3' id='logoside'>
<div class='row w3-center'>
  <div class='col'>
    <i class='fa fa-bars hideme' style='color:#fff;cursor: pointer;' id='bars2'></i>
  </div>
  <div class='col'>
    <a href='index.php' style='text-decoration:none;color:#fff;'><h3 class='logotxt'>Artisan</h3></a>
  </div>
</div>
</div>
<div class='col-sm-6 w3-center' id='menu1'>
  <ul class='homeul'>
     <li><a href='index.php'><i class='fa fa-home' style='font-weight: bold;'></i> Home</a></li>
      <li id='collection'>Collection</li>
      <li><a href='shipped.php'>Shipping</a></li>
      <li><a href='installed.php'>Installation</a></li>
      <li><a href='about.php'>About us</a></li>
      <li><a href='index.php#Contact'>Contact</a></li>
  </ul>
</div> 
<div class='col-sm-3 w3-center' id='sellmenu'>
<button class='seller' id='toggleButton' onclick=\"toggleAccountType();location.href = location.href;\">Switch to Seller</button>
<a href='cart.php' style='text-decoration: none;'><button class='seller'><i class='fa fa-shopping-cart'></i> <span style='font-size: 0.7em;'>0</span></button></a>
<a href='search.php' style='text-decoration: none;'><button class='seller' id='search'><i class='fa fa-search'></i></button></a>
<a href='login.php' style='text-decoration: none;'><button class='seller' id='login'>Login</button></a>
</div>   
</div>    
</header>
</div>
<div class='row menulist' id='menulist'>
<ul>
";
echo showtypes();
echo "
</ul>
</div>";
}
else{
  $type = $_SESSION['type'];
  $idp = $_SESSION['uid'];
  if($type=="buyer"){
    echo "
    <div class='w3-row leftmenuhide' id='leftmenuhide'>
    <div class='w3-row'>
        <button class='times' id='times'><i class='fa fa-times'></i></button>
    </div>
    <div class='w3-row'>
    <ul class='sideul'>
      <li><a href='seller.php'>Profile</a></li>
      <li><a href='index.php'>Home</a></li>
      <li><a href='shipped.php'>Shipping</a></li>
      <li><a href='search.php'>Search</a></li>
      <li><a href='installed.php'>Installation</a></li>
      <li><a href='about.php'>About us</a></li>
      <li><a href='index.php#Contact'>Contact</a></li>
      <li><a href='process/logout.php'>logout</a></li>
 </ul>
  </div>
</div>
<div class='row'>
<header>
<div class='row'>
<div class='col-sm-3' id='logoside'>
  <div class='row w3-center'>
    <div class='col'>
      <i class='fa fa-bars hideme' style='color:#fff;cursor: pointer;' id='bars2'></i>
    </div>
    <div class='col'>
      <a href='index.php' style='text-decoration:none;color:#fff;'><h3 class='logotxt'>Artisan</h3></a>
    </div>
  </div>
</div>
<div class='col-sm-6 w3-center' id='menu1'>
    <ul class='homeul'>
    <li><a href='seller.php'><i class='fa fa-user-o' style='font-weight: bold;'></i></a></li>
    <li><a href='index.php'>Home</a></li>
        <li id='collection'>Collection</li>
        <li><a href='shipped.php'>Shipping</a></li>
        <li><a href='installed.php'>Installation</a></li>
        <li><a href='about.php'>About us</a></li>
        <li><a href='index.php#Contact'>Contact</a></li>
    </ul>
</div> 
<div class='col-sm-3 w3-center' id='sellmenu'>
<button class='seller' id='toggleButton' onclick=\"toggleAccountType();location.href = location.href;\">Switch to Seller</button>
  <a href='cart.php' style='text-decoration: none;'><button class='seller'><i class='fa fa-shopping-cart'></i> <span style='font-size: 0.7em;'>"; echo count_cart(); echo "</span></button></a>
  <a href='search.php' style='text-decoration: none;'><button class='seller' id='search'><i class='fa fa-search'></i></button></a>
  <a href='process/logout.php' style='text-decoration: none;'><button class='seller' id='login'><i class='fa fa-sign-out'></i></button></a>
</div>   
</div>    
</header>
</div>
<div class='row menulist' id='menulist'>
<ul>";
echo showtypes();
echo "
</ul>
</div>";
}
else{
  echo "
  <div class='w3-row leftmenuhide' id='leftmenuhide'>
  <div class='w3-row'>
      <button class='times' id='times'><i class='fa fa-times'></i></button>
  </div>
  <div class='w3-row'>
  <ul class='sideul'>
  <li><a href='seller.php'>Profile</a></li>
  <li><a href='index.php'>Home</a></li>
    <li><a href='shipped.php'>Shipping</a></li>
    <li><a href='search.php'>Search</a></li>
    <li><a href='installed.php'>Installation</a></li>
    <li><a href='about.php'>About us</a></li>
    <li><a href='index.php#Contact'>Contact</a></li>
    <li><a href='process/logout.php'>Logout</a></li>
</ul>
</div>
</div>
<div class='row'>
<header>
<div class='row'>
<div class='col-sm-3' id='logoside'>
<div class='row w3-center'>
  <div class='col'>
    <i class='fa fa-bars hideme' style='color:#fff;cursor: pointer;' id='bars2'></i>
  </div>
  <div class='col'>
    <a href='index.php' style='text-decoration:none;color:#fff;'><h3 class='logotxt'>Artisan</h3></a>
  </div>
</div>
</div>
<div class='col-sm-6 w3-center' id='menu1'>
  <ul class='homeul'>
  <li><a href='seller.php'><i class='fa fa-user-o' style='font-weight: bold;'></i></a></li>
  <li><a href='index.php'>Home</a></li>
      <li id='collection'>Collection</li>
      <li><a href='shipped.php'>Shipping</a></li>
      <li><a href='installed.php'>Installation</a></li>
      <li><a href='about.php'>About us</a></li>
      <li><a href='index.php#Contact'>Contact</a></li>
  </ul>
</div> 
<div class='col-sm-3 w3-center' id='sellmenu'>
<button class='seller' id='toggleButton' onclick=\"toggleAccountType();location.href = location.href;\">Switch to Buyer</button>
<a href='cart.php' style='text-decoration: none;'><button class='seller'><i class='fa fa-shopping-cart'></i> <span style='font-size: 0.7em;'>"; echo count_cart(); echo "</span></button></a>
<a href='search.php' style='text-decoration: none;'><button class='seller' id='search'><i class='fa fa-search'></i></button></a>
<a href='process/logout.php' style='text-decoration: none;'><button class='seller' id='login'><i class='fa fa-sign-out'></i></button></a>
</div>   
</div>    
</header>
</div>
<div class='row menulist' id='menulist'>
<ul>";
echo showtypes();
echo "
</ul>
</div>";
} 
}
?>
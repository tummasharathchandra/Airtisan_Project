<footer>
    <div class="row w3-center">
      <div class="col">
      <a href="index.php" style="text-decoration:none;color:#000;">  
       <img src="logo/logo.jpg">
        <h3 style="font-variant:small-caps;">Local Artisan Marketplace</h3></a>
      </div>
      <div class="col" id="Contact">
        <h3>Contact</h3>
          <button class="seller"><i class="fa fa-facebook"></i></button>
          <button class="seller"><i class="fa fa-linkedin"></i></button>
          <button class="seller"><i class="fa fa-twitter"></i></button>
      </div>
      <div class="col">
        <ul class="footerul">
          <li><a href="feedbacks.php">Feedback</a></li>
          <li><a href="about.php">About us</a></li>
          <li><a href="index.php#Contact">Contact us</a></li>
          <li>Copyright &copy; 2024 Local Artisan Marketplace </li>
        </ul>
      </div>
    </div>
  </footer>

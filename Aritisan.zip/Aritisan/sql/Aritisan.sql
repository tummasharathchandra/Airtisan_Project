-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Aritisan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buyitems`
--

CREATE TABLE `buyitems` (
  `byid` int(11) NOT NULL,
  `byquantity` text NOT NULL,
  `byprice` text NOT NULL,
  `bydate` text NOT NULL,
  `itemid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buyitems`
--

INSERT INTO `buyitems` (`byid`, `byquantity`, `byprice`, `bydate`, `itemid`, `uid`) VALUES
(1, '1', '200', '2023/03/28', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `itemid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `fid` int(11) NOT NULL,
  `fname` text NOT NULL,
  `fdes` text NOT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`fid`, `fname`, `fdes`, `uid`) VALUES
(1, 'Sitting', 'The best sofa ever', 2),
(3, 'Room', 'The best sofa ever', 2),
(4, 'HD', 'The best sofa ever', 2),
(5, 'Side', 'The best room ever', 2);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `itemid` int(11) NOT NULL,
  `itemname` text NOT NULL,
  `itemdes` text NOT NULL,
  `itemprice` text NOT NULL,
  `itemquantity` text NOT NULL,
  `itemcolor` text NOT NULL,
  `itemimage` text NOT NULL,
  `itemcat` text NOT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`itemid`, `itemname`, `itemdes`, `itemprice`, `itemquantity`, `itemcolor`, `itemimage`, `itemcat`, `uid`) VALUES
(1, 'HD TV', 'Best TV', '100', '3', 'Black', 'tv.jpg', 'TV Collection', 2),
(2, 'Sony TV', 'Best TV', '200', '1', 'Black', 'tv-g.png', 'TV Collection', 2),
(3, 'Smart TV', 'Best TV', '200', '2', 'Black', 'smart-tv.png', 'TV Collection', 2),
(4, 'Bed Sofa', 'Best Sofa', '100', '2', 'Black', 'sofa1.jpg', 'Sofa Collection', 2),
(5, 'Sitting Sofa', 'Best Sofa', '200', '2', 'White', 'sofa2.jpg', 'Sofa Collection', 2),
(6, 'Room Sofa', 'Best Sofa', '100', '1', 'Multi color', 'sofa3.jpg', 'Sofa Collection', 2),
(7, 'Dining chairs', 'Best Chairs', '100', '2', 'Black', 'chairs1.jpg', 'Dining Collection', 2),
(8, 'Meeting Chairs', 'Best Chairs', '200', '2', 'White', 'chairs2.jpg', 'Dining Collection', 2),
(9, 'Room Chairs', 'Best Chairs', '200', '2', 'Black', 'chairs3.jpg', 'Dining Collection', 2),
(10, 'Sitting Couch', 'Best couch', '100', '1', 'White', 'couch1.jpg', 'Couchs', 2),
(11, 'Lying couch', 'Best couch', '200', '2', 'marron', 'couch2.png', 'Couchs', 2),
(12, 'Side couch', 'Best couch', '100', '1', 'Black', 'couch3.jpg', 'Couchs', 2),
(13, 'Living House', 'Best House', '100', '3', 'Multi color', 'house1.jpg', 'house', 2),
(14, 'Old house', 'Best House', '200', '1', 'White', 'house2.jpg', 'house', 2),
(15, 'Sold House', 'Best House', '100', '2', 'White', 'house3.jpg', 'house', 2),
(16, 'Living Room', 'Best Room', '100', '2', 'Black', 'room.jpg', 'Room', 2),
(17, 'Drawing Room', 'Best Room', '200', '2', 'White', 'room1.jpg', 'Room', 2),
(18, 'Side Room', 'Best Room', '100', '1', 'Black', 'room2.jpg', 'Room', 2),
(19, 'Inner Interior', 'Best Interior', '100', '1', 'multi', 'interior1.jpg', 'Interior', 2),
(20, 'Outer Interior', 'Best Interior', '200', '2', 'Multi color', 'interior2.jpg', 'Interior', 2),
(21, 'Side Interior', 'Best Interior', '100', '1', 'Black', 'interior3.jpg', 'Interior', 2);

-- --------------------------------------------------------

--
-- Table structure for table `itemtype`
--

CREATE TABLE `itemtype` (
  `tyid` int(11) NOT NULL,
  `tyname` text NOT NULL,
  `tydes` text NOT NULL,
  `tyimg` text NOT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `itemtype`
--

INSERT INTO `itemtype` (`tyid`, `tyname`, `tydes`, `tyimg`, `id`) VALUES
(1, 'TV Collection', 'an electronic system of transmitting images with sound over a wire or through space by devices that change light and sound into electrical waves and then change these back into light and sound.', 'smart-tv.png', 2),
(2, 'Sofa Collection', 'best sofa for living room Comfortable sofas and armchairs allow you to have your own warm seat. best sofa for living room sofas are rich in colors, varied textures, and diverse styles. Quick Delivery.', 'sofa4.jpg', 2),
(3, 'Dining Collection', 'We gathered these Restaurant Description examples for those who want to save some time on writing their own about us page for the website.', 'chairs2.jpg', 2),
(4, 'Room', 'space that can be occupied or where something can be done, a part or division of a building enclosed by walls, floor, and ceiling, share a room, house, or flat, especially a rented one at a college or similar institution.', 'room1.jpg', 2),
(5, 'house', 'best chairs for living room Comfortable chairs and armchairs allow you to have your own warm seat. best chair for living room chairs are rich in colors, varied textures, and diverse styles. Quick Delivery.', 'house1.jpg', 2),
(6, 'Couchs', 'best sofa for living room Comfortable sofas and armchairs allow you to have your own warm seat. best sofa for living room sofas are rich in colors, varied textures, and diverse styles. Quick Delivery.', 'couch1.jpg', 2),
(7, 'Interior', 'space that can be occupied or where something can be done, a part or division of a building enclosed by walls, floor, and ceiling, share a room, house, or flat, especially a rented one at a college or similar institution.', 'interior1.jpg', 2),
(8, 'Beds Collection', 'best bed for living room Comfortable beds and armchairs allow you to have your own warm seat. best bed for living room beds are rich in colors, varied textures, and diverse styles. Quick Delivery.', 'bedroom.jpg', 2),
(9, 'Clocks', 'We gathered these Restaurant Description examples for those who want to save some time on writing their own about us page for the website.', 'clock.jpg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `sellitems`
--

CREATE TABLE `sellitems` (
  `seid` int(11) NOT NULL,
  `sequantity` text NOT NULL,
  `seprice` text NOT NULL,
  `sedate` text NOT NULL,
  `sestatus` text NOT NULL,
  `itemid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sellitems`
--

INSERT INTO `sellitems` (`seid`, `sequantity`, `seprice`, `sedate`, `sestatus`, `itemid`, `uid`) VALUES
(1, '1', '200', '2023/03/28', 'installed', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `pnumber` text NOT NULL,
  `email` text NOT NULL,
  `pass` text NOT NULL,
  `uprofile` text NOT NULL,
  `utype` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `fname`, `lname`, `pnumber`, `email`, `pass`, `uprofile`, `utype`) VALUES
(1, 'Numan', 'Ahmed', 'admin', 'admin@gmail.com', 'admin', 'profile.png', 'owner'),
(2, 'Aslam', 'Ali', '03322761838', 'aslam@gmail.com', '12345', 'profile.png', 'seller');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buyitems`
--
ALTER TABLE `buyitems`
  ADD PRIMARY KEY (`byid`),
  ADD KEY `itemid` (`itemid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `itemid` (`itemid`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`fid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`itemid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `itemtype`
--
ALTER TABLE `itemtype`
  ADD PRIMARY KEY (`tyid`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `sellitems`
--
ALTER TABLE `sellitems`
  ADD PRIMARY KEY (`seid`),
  ADD KEY `itemid` (`itemid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buyitems`
--
ALTER TABLE `buyitems`
  MODIFY `byid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `itemid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `itemtype`
--
ALTER TABLE `itemtype`
  MODIFY `tyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sellitems`
--
ALTER TABLE `sellitems`
  MODIFY `seid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buyitems`
--
ALTER TABLE `buyitems`
  ADD CONSTRAINT `buyitems_ibfk_1` FOREIGN KEY (`itemid`) REFERENCES `items` (`itemid`),
  ADD CONSTRAINT `buyitems_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`itemid`) REFERENCES `items` (`itemid`);

--
-- Constraints for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`);

--
-- Constraints for table `itemtype`
--
ALTER TABLE `itemtype`
  ADD CONSTRAINT `itemtype_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`uid`);

--
-- Constraints for table `sellitems`
--
ALTER TABLE `sellitems`
  ADD CONSTRAINT `sellitems_ibfk_1` FOREIGN KEY (`itemid`) REFERENCES `items` (`itemid`),
  ADD CONSTRAINT `sellitems_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

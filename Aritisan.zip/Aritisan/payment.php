<?php 
session_start();
$id=$_GET['id'];
$pay=$_GET['pay'];
include "process/process.php";
include "switch.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Payment</title>
    <?php include "headlinks.php";?>
    <style>.card:hover{opacity: 1;}</style>
    </head>
    <body onload="showsidebar();hidesidebar();showmenu()"> 
    <?php include "header.php";?>
<div class="row" style="width:40%;margin:auto;margin-top: 80px;">
  <h2 style="margin-top: 10px;margin-bottom: 10px;">Payment procedure: <i class="fa fa-shopping-cart"></i></h2>
  <form class="itemform" action="process/complete.php" style="border: none;" method="post">
    <input type="text" name="payment" value=<?php echo $pay."$";?> style="font-size:1.2em;font-weight:bold;" />
    <h6 style="margin-top: 10px;margin-bottom: 10px;text-align:left;">Installation</h6>
    <select name="install">
      <option>Install</option>
      <option selected>none</option>
    </select>
    <input type="submit" id="submit" value="OK, Finish Payment" name="complete" />
    <a href="cart.php" style="text-decoration: none;"><input type="button" id="submit" value="No, Cancel Payment" /></a>
  </form>
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>













<?php 
session_start();
include "process/process.php";
include "switch.php";
$profile = $_SESSION['profile'];
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Seller Dashboard</title>
<?php include "headlinks.php";?>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey" onload="showsidebar();hidesidebar();showmenu()"> 
<?php include "header.php";?>
<?php include "leftmenu.php";?>
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<div class="w3-main w3-center content">
    <form class="itemform" action="process/process.php" method="post" enctype="multipart/form-data">
      <img src='<?php echo "images/".$profile;?>' style="width: 100px;height: 100px;border-radius: 50%;" />
      <h2>Profile</h2>
      <input type="file" name="pimg" required />
      <input type="submit" value="Update" name="update_profile" id="submit" />
    </form>  
    <hr class="hr" />
    <form class="itemform" action="process/process.php" method="post">
      <h2>Basic Infomation</h2>
      <input type="text" name="fnameS" id="fname" placeholder="First name" required value="<?php echo $_SESSION['fname'];?>" />
      <input type="text" name="lnameS" id="lname" placeholder="Last name" required value="<?php echo $_SESSION['lname'];?>" />
      <input type="text" name="numberS" id="number" placeholder="Phone Number" required value="<?php echo $_SESSION['number'];?>" />
      <input type="email" name="email" id="email" placeholder="Email" required value="<?php echo $_SESSION['email'];?>" />
      <input type="password" name="pass" id="pass" placeholder="Password" required value="<?php echo $_SESSION['password'];?>" />
        <input type="submit" value="Update" id="submit" name="update_info" />
    </form>  
      <hr class="hr" />
      <form class="itemform" action="process/process.php" method="post">
        <h2>Account</h2>
          <input type="submit" value="Delete" id="submit" name="delete_account" />
      </form>  
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>

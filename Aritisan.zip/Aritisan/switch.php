<?php
if (isset($_POST['toggleAccountType'])) {
    $currentAccountType = $_SESSION['type'];
    if ($currentAccountType === 'buyer') {
        $_SESSION['type'] = 'seller';
        header("location:seller.php");
    } else {
        $_SESSION['type'] = 'buyer';
        header("location:seller.php");
    }
    echo $_SESSION['type'];
    exit;
}  
?>

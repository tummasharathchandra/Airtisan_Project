<?php 
session_start();
$uid=$_SESSION['uid'];
include "process/process.php";
include "switch.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Cart</title>
    <?php include "headlinks.php";?>
    <style>.card:hover{opacity: 1;}</style>
    </head>
    <body onload="showsidebar();hidesidebar();showmenu()"> 
    <?php include "header.php";?>
<div class="row" style="width:70%;margin:auto;margin-top: 80px;">
  <h2 style="margin-top: 10px;margin-bottom: 10px;">Items added to Cart <i class="fa fa-shopping-cart"></i></h2>
<?php echo show_cart_items();?>
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>













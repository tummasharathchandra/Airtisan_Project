<?php
    include "../process/conn.php";
    $id=$_GET['id'];
        $sql = "DELETE FROM users WHERE uid='$id'";    
        if ($conn->query($sql) ==TRUE){
                header("location:message3.php");
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
    $conn->close(); 
?>
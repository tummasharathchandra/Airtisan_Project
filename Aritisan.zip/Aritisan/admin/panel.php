<?php 
session_start();
include "../process/process.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<?php include "admin-headlinks.php";?>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey" onload="showsidebar();hidesidebar();showmenu()"> 
<?php include "admin-header.php";?>
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;margin-top: 50px;" id="mySidebar"><br>
    <div class="w3-container w3-row">
      <div class="w3-col s3">
        <img src="../images/profile.png" class="w3-margin-right" style="width:50px;height:50px;border-radius:50%;">
      </div>
      <div class="w3-col s9 w3-bar" style="margin-top: 15px;">
      <span>Welcome, <strong> Admin</strong></span>
      </div>
    </div>
    <hr>
    <div class="w3-container">
      <h5>Dashboard</h5>
    </div>
    <div class="w3-bar-block">
      <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
      <a href="panel.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-users fa-fw"></i>  Overview</a>
      <a href="add-product.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  Add Product</a>
      <a href="add-user.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  Add User</a>
      <a href="delete-products.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-shopping-cart"></i>  Delete Products</a>
      <a href="delete-users.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-user"></i>  Remove Users</a>
    </div>
  </nav> 
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<div class='w3-main' style='margin-left:300px;margin-top:80px;'>
    <div class='w3-row-padding w3-margin-bottom'>
    <div class='w3-quarter'>
      <a href='add-user.php' style='text-decoration: none;'>
      <div class='w3-container w3-yellow w3-padding-16'>
          <div class='w3-left'><i class='fa fa-plus w3-xxxlarge'></i></div>
          <div class='w3-clear'></div>
          <h4>Add User</h4>
        </div>
      </a>
      </div>
      <div class='w3-quarter'>
      <a href='add-product.php' style='text-decoration: none;'>    
      <div class='w3-container w3-red w3-padding-16'>
          <div class='w3-left'><i class='fa fa-plus w3-xxxlarge'></i></div>
          <div class='w3-right'>
          </div>
          <div class='w3-clear'></div>
          <h4>Add Product</h4>
        </div>
      </a>
      </div>      
    <div class='w3-quarter'>
      <a href='delete-items.php' style='text-decoration: none;'>
      <div class='w3-container w3-blue w3-padding-16'>
          <div class='w3-left'><i class='fa fa-shopping-cart w3-xxxlarge'></i></div>
          <div class='w3-clear'></div>
          <h4>Delete Items</h4>
        </div>
      </a>
      </div>
      <div class='w3-quarter'>
      <a href='delete-users.php' style='text-decoration: none;'>    
      <div class='w3-container w3-teal w3-padding-16'>
          <div class='w3-left'><i class='fa fa-user w3-xxxlarge'></i></div>
          <div class='w3-right'>
          </div>
          <div class='w3-clear'></div>
          <h4>Delete Users</h4>
        </div>
      </a>
      </div>

    </div>
  </div>
</body>
</html>

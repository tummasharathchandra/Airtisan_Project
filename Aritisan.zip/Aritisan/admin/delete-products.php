<?php 
session_start();
include "../process/process.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:../login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<?php include "admin-headlinks.php";?>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
.panel-table{
  width: 100%;
  height: auto;
  background: #fff;
  border-collapse: collapse;
}
.panel-table th,.panel-table td{
  height: 50px;
  border: 1px solid #f1f1f1;
  padding: 1%;
  text-align: center;
}
.panel-table td a{
  text-decoration: none;
}
.panel-table td a button{
  width: 50px;
  height: 40px;
  border: none;
  outline: none;
  background: #ff0000;
  color: #fff;
}

</style>
</head>
<body class="w3-light-grey" onload="showsidebar();hidesidebar();showmenu()"> 
<?php include "admin-header.php";?>
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;margin-top: 50px;" id="mySidebar"><br>
    <div class="w3-container w3-row">
      <div class="w3-col s3">
        <img src="../images/profile.png" class="w3-margin-right" style="width:50px;height:50px;border-radius:50%;">
      </div>
      <div class="w3-col s9 w3-bar" style="margin-top: 15px;">
      <span>Welcome, <strong> Admin</strong></span>
      </div>
    </div>
    <hr>
    <div class="w3-container">
      <h5>Dashboard</h5>
    </div>
    <div class="w3-bar-block">
      <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
      <a href="panel.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-users fa-fw"></i>  Overview</a>
      <a href="add-product.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  Add Product</a>
      <a href="add-user.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  Add User</a>
      <a href="delete-products.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-shopping-cart"></i>  Delete Products</a>
      <a href="delete-users.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-user"></i>  Remove Users</a>
    </div>
  </nav> 
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<div class='w3-main' style='margin-left:300px;margin-top:70px;'>
<div class="w3-row w3-center" style="margin-bottom: 50px;">
      <center>
      <h1>Products Data</h1>
      <table class="panel-table">
        <tr>
          <th>Item Name</th>
          <th>Item Price</th>
          <th>Item Quantity</th>
          <th>Item Color</th>
          <th>Item Category</th>
          <th>Action</th>
        </tr>
        <?php
            include "../process/conn.php";
            $sql = "SELECT * FROM items";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                        $itemid=$row['itemid'];
                        $itemname=$row['itemname'];            
                        $itemprice=$row['itemprice'];
                        $itemquantity=$row['itemquantity'];
                        $itemcolor=$row['itemcolor'];
                        $itemcat=$row['itemcat'];
                        echo "
                        <tr>
                        <td>$itemname</td>
                        <td>$itemprice</td>
                        <td>$itemquantity</td>
                        <td>$itemcolor</td>
                        <td>$itemcat</td>
                        <td><a href='delete-products-data.php?id=$itemid'><button><i class='fa fa-times'></i></button></a></td>
                        </tr>              
                        ";
                        }       
            }
            else {
                echo "<h1 style='color:#f00;'>0 Users</h1>";
                }
            $conn->close();        
        ?>
      </table>
      </center>    
    </div>
</div>
</body>
</html>

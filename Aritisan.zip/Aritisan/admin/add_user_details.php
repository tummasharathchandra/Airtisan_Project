<?php
if(isset($_POST['add_user']))
{add_user();} 
function add_user(){
    include "../process/conn.php";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fname=$_POST['fnameS'];        
        $lname=$_POST['lnameS'];        
        $number=$_POST['numberS'];        
        $email=$_POST['email']; 
        $pass=$_POST['pass']; 
        $uprofile="profile.png";
        $utype="buyer"; 
        $sql = "INSERT INTO users(fname,lname,pnumber,email,pass,uprofile,utype) VALUES('$fname','$lname','$number','$email','$pass','$uprofile','$utype')";    
        if ($conn->query($sql) ==TRUE){
            header("location:message.php");    
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Account not created";
    }    
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <?php include "admin-headlinks.php";?>
    </head>
    <body> 
    <div class="row"> 
    <header>
        <div class="row" style="margin-top:-4px;">
        <center>
            <a href="../index.php" style="text-decoration:none;color:#fff;"><h3 style="font-variant:small-caps;color:white;">Aritisan</h3></a>
        </center>
        </div>    
    </header>
</div> 
    <div class="row w3-center" style="margin-bottom: 100px;">
        <center>
    <form class="form" autocomplete="off" action="login_validate.php" method="post"> 
        <h1>Admin Login</h1> <br />   
        <input type="text" name="number" placeholder="Enter username" required />
        <input type="password" name="password" placeholder="Enter password" required />
        <input type="submit" id="submit" value="Login" name="login_user" />
    </form>
    </center>    
    </div> 
</body>
</html>
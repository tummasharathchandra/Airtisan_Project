<?php
session_start();
unset($_SESSION['pass']);
unset($_SESSION['number']);
session_destroy();
header("location:login.php");
exit();
?>
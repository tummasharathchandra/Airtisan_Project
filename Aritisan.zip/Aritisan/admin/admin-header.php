<?php
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  echo "
  <div class='w3-row leftmenuhide' id='leftmenuhide'>
  <div class='w3-row'>
      <button class='times' id='times'><i class='fa fa-times'></i></button>
  </div>
  <div class='w3-row'>
  <ul class='sideul'>
    <li><a href='login.php'>login</a></li>
</ul>
</div>
</div>
<div class='row'>
<header>
<div class='row'>
<div class='col-sm-3' id='logoside'>
<div class='row w3-center'>
  <div class='col'>
    <i class='fa fa-bars hideme' style='color:#fff;cursor: pointer;' id='bars2'></i>
  </div>
  <div class='col'>
    <a href='panel.php' style='text-decoration:none;color:#fff;'><h3 class='logotxt'>Aritisan</h3></a>
  </div>
</div>
</div>
<div class='col-sm-6 w3-center' id='menu1'>
  <ul class='homeul'>
      <li>&nbsp;</li>
  </ul>
</div> 
<div class='col-sm-3 w3-center' id='sellmenu'>
<a href='login.php' style='text-decoration: none;'><button class='seller' id='login'>Login</button></a>
</div>   
</div>    
</header>
</div>
<div class='row menulist' id='menulist'>
<ul>
";
echo showtypes();
echo "
</ul>
</div>";
}
else{
  $type = $_SESSION['type'];
  $idp = $_SESSION['uid'];
  if($type=="buyer"){
    echo "
    <div class='w3-row leftmenuhide' id='leftmenuhide'>
    <div class='w3-row'>
        <button class='times' id='times'><i class='fa fa-times'></i></button>
    </div>
    <div class='w3-row'>
    <ul class='sideul'>
      <li><a href='logout.php'>logout</a></li>
 </ul>
  </div>
</div>
<div class='row'>
<header>
<div class='row'>
<div class='col-sm-3' id='logoside'>
  <div class='row w3-center'>
    <div class='col'>
      <i class='fa fa-bars hideme' style='color:#fff;cursor: pointer;' id='bars2'></i>
    </div>
    <div class='col'>
      <a href='panel.php' style='text-decoration:none;color:#fff;'><h3 class='logotxt'>Aritisan</h3></a>
    </div>
  </div>
</div>
<div class='col-sm-6 w3-center' id='menu1'>
    <ul class='homeul'>
        <li>&nbsp;</li>
    </ul>
</div> 
<div class='col-sm-3 w3-center' id='sellmenu'>
  <a href='logout.php' style='text-decoration: none;'><button class='seller' id='login'><i class='fa fa-sign-out'></i></button></a>
</div>   
</div>    
</header>
</div>
<div class='row menulist' id='menulist'>
<ul>";
echo showtypes();
echo "
</ul>
</div>";
}
else{
  echo "
  <div class='w3-row leftmenuhide' id='leftmenuhide'>
  <div class='w3-row'>
      <button class='times' id='times'><i class='fa fa-times'></i></button>
  </div>
  <div class='w3-row'>
  <ul class='sideul'>
    <li><a href='logout.php'>Logout</a></li>
</ul>
</div>
</div>
<div class='row'>
<header>
<div class='row'>
<div class='col-sm-3' id='logoside'>
<div class='row w3-center'>
  <div class='col'>
    <i class='fa fa-bars hideme' style='color:#fff;cursor: pointer;' id='bars2'></i>
  </div>
  <div class='col'>
    <a href='panel.php' style='text-decoration:none;color:#fff;'><h3 class='logotxt'>Aritisan</h3></a>
  </div>
</div>
</div>
<div class='col-sm-6 w3-center' id='menu1'>
  <ul class='homeul'>
      <li>&nbsp;</li>
  </ul>
</div> 
<div class='col-sm-3 w3-center' id='sellmenu'>
<a href='logout.php' style='text-decoration: none;'><button class='seller' id='login'><i class='fa fa-sign-out'></i></button></a>
</div>   
</div>    
</header>
</div>
<div class='row menulist' id='menulist'>
<ul>";
echo showtypes();
echo "
</ul>
</div>";
} 
}
?>
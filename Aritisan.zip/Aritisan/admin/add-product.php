<?php 
session_start();
include "../process/process.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:../login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<?php include "admin-headlinks.php";?>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey" onload="showsidebar();hidesidebar();showmenu()"> 
<?php include "admin-header.php";?>
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;margin-top: 50px;" id="mySidebar"><br>
    <div class="w3-container w3-row">
      <div class="w3-col s3">
        <img src="../images/profile.png" class="w3-margin-right" style="width:50px;height:50px;border-radius:50%;">
      </div>
      <div class="w3-col s9 w3-bar" style="margin-top: 15px;">
      <span>Welcome, <strong> Admin</strong></span>
      </div>
    </div>
    <hr>
    <div class="w3-container">
      <h5>Dashboard</h5>
    </div>
    <div class="w3-bar-block">
      <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
      <a href="panel.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-users fa-fw"></i>  Overview</a>
      <a href="add-product.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  Add Product</a>
      <a href="add-user.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-plus"></i>  Add User</a>
      <a href="delete-products.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-shopping-cart"></i>  Delete Products</a>
      <a href="delete-users.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-user"></i>  Remove Users</a>
    </div>
  </nav> 
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<div class='w3-main' style='margin-left:200px;margin-top:100px;'>
<div class="w3-row w3-center" style="margin-bottom: 50px;">
        <center>
      <form class="itemform" action="add_product_details.php" method="POST" enctype="multipart/form-data">
    <h2>Add Item</h2>
    <input type="text" name="itemname" placeholder="Item Name" />
    <input type="text" name="itemdes" placeholder="Item Description" />
    <select name="type">
       <?php echo showtypes2();?>
    </select>
    <input type="text" name="itemprice" placeholder="Item Price" />
    <input type="number" name="itemquantity" placeholder="Item Quantity" />
    <input type="text" name="itemcolor" placeholder="Item Color" />
    <input type="file" name="itemimage" />
    <input type="submit" value="Add Item" name="add_items" id="submit" />
    </form>
      </center>    
    </div>
</div>
</body>
</html>

<?php
    include "../process/conn.php";
    $id=$_GET['id'];
        $sql = "DELETE FROM items WHERE itemid='$id'";    
        if ($conn->query($sql) ==TRUE){
                header("location:message4.php");
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
    $conn->close(); 
?>
<?php
if(isset($_POST['add_items']))
{add_items();} 
function add_items(){
    session_start();
    include "../process/conn.php";
    $id=$_SESSION['uid'];
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $uploads_dir = '../images';
        $temp_name = $_FILES["itemimage"]["tmp_name"];
        $name = basename($_FILES["itemimage"]["name"]);
        $itemname=$_POST['itemname'];        
        $itemdes=$_POST['itemdes'];        
        $type=$_POST['type'];        
        $itemprice=$_POST['itemprice']; 
        $itemquantity=$_POST['itemquantity']; 
        $itemcolor=$_POST['itemcolor']; 
        $sql = "INSERT INTO items(itemname,itemdes,itemprice,itemquantity,itemcolor,itemimage,itemcat,uid) VALUES('$itemname','$itemdes','$itemprice','$itemquantity','$itemcolor','$name','$type','$id')";    
        if ($conn->query($sql) ==TRUE){
            if(move_uploaded_file($temp_name, "$uploads_dir/$name")){
                header("location:message2.php");    
            }
        } 
        else {
            echo "Error: " . $sql . "<br />" . $conn->error. " <br />";
        }
            $conn->close(); 
    }
    else{
            echo "Item not Added";
    }    
}
?>
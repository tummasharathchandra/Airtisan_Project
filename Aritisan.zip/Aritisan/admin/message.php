<?php 
session_start();
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Success</title>
    <?php include "admin-headlinks.php";?>
    </head>
    <body>
    <div class="row"> 
    <header>
        <div class="row" style="margin-top:-4px;">
        <center>
            <a href="panel.php" style="text-decoration:none;color:#fff;"><h3 style="font-variant:small-caps;color:white;">Furniture</h3></a>
        </center>
        </div>    
    </header>
    <div class="w3-row w3-center" style="margin-bottom: 100px;margin-top: 200px;">
        <center>
        <h1>User Added Successfully!</h1> <br />   
       <a href="add-user.php" style="text-decoration: none;color:#fff;"><button type="button" class="button2">Ok</button></a>    
    </center>    
    </div>
</body>
</html> 
<?php
if(isset($_POST['login_user']))
{login_user();} 
function login_user(){
    session_start();
    include "../process/conn.php";
    if($_SERVER["REQUEST_METHOD"]== "POST"){   
        $number =$_POST['number'];
        $password = $_POST['password'];
        $que = "SELECT * FROM users WHERE pnumber = '$number' AND pass = '$password'";
            $result = $conn->query($que);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $uid=$row['uid'];
                    $fname = $row['fname'];
                    $lname = $row['lname'];
                    $num = $row['pnumber'];                
                    $email = $row['email'];
                    $pass = $row['pass'];
                    $profile = $row['uprofile'];
                    $type = $row['utype'];
                    if($password==$pass && $number==$num) {  
                     $_SESSION['uid'] = $uid;
                     $_SESSION['fname'] = $fname;
                     $_SESSION['lname'] = $lname;
                     $_SESSION['number'] = $num;
                     $_SESSION['email'] = $email;
                     $_SESSION['password'] =$pass;
                     $_SESSION['profile'] =$profile;
                     $_SESSION['type'] = $type;
                     header("location:panel.php");                                               
                    }
            }
        } 
        else{
            echo "<script>alert('Sad...! You entered wrong number or password.');window.location.href ='../login.php';</script>";
        }      
        $conn->close();
    }    
 }
?>


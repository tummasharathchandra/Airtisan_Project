<?php 
session_start();
include "process/process.php";
include "switch.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Seller Dashboard</title>
<?php include "headlinks.php";?>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
</head>
<body class="w3-light-grey" onload="showsidebar();hidesidebar();showmenu()"> 
<?php include "header.php";?>
<?php include "leftmenu.php";?>
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<div class="w3-main w3-center content">
  <form class="itemform" action="process/process.php" method="POST" enctype="multipart/form-data">
    <h2>Add furniture</h2>
    <input type="text" name="itemname" placeholder="Item Name" />
    <input type="text" name="itemdes" placeholder="Item Description" />
    <select name="type">
       <?php echo showtypes2();?>
    </select>
    <input type="text" name="itemprice" placeholder="Item Price" />
    <input type="number" name="itemquantity" placeholder="Item Quantity" />
    <input type="text" name="itemcolor" placeholder="Item Color" />
    <input type="file" name="itemimage" />
    <input type="submit" value="Add Item" name="add_items" id="submit" />
  </form>
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>

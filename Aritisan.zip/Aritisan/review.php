<?php 
    session_start();

    $uidd=$_GET['id'];
    $name=$_GET['name'];
    $price=$_GET['price'];     
    include "process/process.php";
    include "switch.php";
    if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
      header("location:login.php");
    }    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Feedback</title>
    <?php include "headlinks.php";?>
    <style>.card:hover{opacity: 1;}</style>
    </head>
    <body onload="showsidebar();hidesidebar();showmenu()"> 
    <?php include "header.php";?>
<div class="row" style="width:40%;margin:auto;margin-top: 80px;">
  <h2 style="margin-top: 10px;margin-bottom: 10px;">Give Feedback: <i class="fa fa-diamond"></i></h2>
  <form class="itemform" style="border: none;" action="process/feedback.php" method="post">
    <input type="hidden" name="id" value=<?php echo $uidd;?> style="font-size:1.2em;font-weight:bold;" />
    <input type="text" name="itemname" value=<?php echo $name;?> style="font-size:1.2em;font-weight:bold;" />
    <input type="text" name="itemprice" value=<?php echo $price."$";?> style="font-size:1.2em;font-weight:bold;" />
    <input type="text" name="message" style="height:100px;font-size:1.2em;font-weight:bold;" placeholder="Write here..." />
    <input type="submit" id="submit" value="Send Feedback"/>
    <a href="seller.php" style="text-decoration: none;"><input type="button" id="submit" value="Cancel" /></a>
  </form>
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>













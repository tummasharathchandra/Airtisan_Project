<?php 
session_start();
$c=$_GET['c'];
include "process/process.php";
include "switch.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search Furniture</title>
    <?php include "headlinks.php";?>
    <style>.card:hover{opacity: 1;}</style>
    </head>
    <body onload="showsidebar();hidesidebar();showmenu()"> 
    <?php include "header.php";?>
    <div class="row w3-center" style="margin-top: 80px;">
    <form class="searchitem" action="search.php" method="post">
      <input type="search" name="search" placeholder="Search Furniture..." value="<?php echo $c;?>" />
      <input type="submit" value="Search" id="b" />
    </form>  
    </div>
<div class="row" style="width: 90%;margin: auto;margin-top: 20px;margin-bottom: 5%;">
    <?php
      $uid3=$_SESSION['uid'];
      if (isset($_POST["search"])) {
      require "3-search.php";
      if (count($results) > 0) { foreach ($results as $r) {
                $itemid=$r['itemid'];
                $itemname=$r['itemname'];            
                $itemdes=$r['itemdes'];
                $itemprice=$r['itemprice'];
                $itemcolor=$r['itemcolor'];
                $itemimage=$r['itemimage'];
                $itcat = $_POST["search"];
                echo "
                <div class='col'>
                <div class='card' style='width: 25rem;'>
                  <img src='images/$itemimage' class='card-img-top' alt='...'>
                  <div class='card-body'>
                    <h3>$itemname</h3>
                    <div class='row' style='margin-top: 10px;'>
                      <div class='col'>
                        <p class='card-text'>Price: </p>
                      </div>
                      <div class='col'>
                        <p class='card-text'>$itemprice$</p>
                      </div>
                    </div>
                    <div class='row' style='margin-top: 10px;'>
                      <div class='col'>
                        <p class='card-text'>Description: </p>
                      </div>
                      <div class='col'>
                        <p class='card-text'>$itemdes</p>
                      </div>
                    </div>
                    <div class='row' style='margin-top: 10px;'>
                      <div class='col'>
                        <p class='card-text'>Color: </p>
                      </div>
                      <div class='col'>
                        <p class='card-text'>$itemcolor</p>
                      </div>
                    </div>
                    <div class='row w3-center' style='margin-top: 10px;'>
                    <a href='process/add_cart2.php?uid=$uid3 && itemid=$itemid && cate=$itcat' style='text-decoration:none;'><button class='short' style='width: 90%;float:left;'>Add to Cart <i class='fa fa-shopping-cart'></i></button></a
                      <br /><br />
                    </div>  
                  </div>
                </div>
              </div>
            ";
      
      }} else { echo "No results found"; }
    }
    ?>
</div>
<div class="row" style="margin-top: 20px;">
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>














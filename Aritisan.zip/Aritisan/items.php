<?php 
session_start();
include "process/process.php";
include "switch.php";
if(!isset($_SESSION['number']) && !isset($_SESSION['password'])){
  header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search Furniture</title>
    <?php include "headlinks.php";?>
    <style>.card:hover{opacity: 1;}</style>
    </head>
    <body onload="showsidebar();hidesidebar();showmenu()"> 
    <?php include "header.php";?>
    <div class="row w3-center" style="margin-top: 80px;">
    </div>
<div class="row" style="width: 90%;margin: auto;margin-top: 20px;margin-bottom: 5%;">
  <?php echo show_items();?>
</div>
<div class="row" style="margin-top: 20px;">
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>














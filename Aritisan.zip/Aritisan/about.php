<?php 
session_start();
include "process/process.php";
include "switch.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us</title>
    <?php include "headlinks.php";?>
    <style>.card:hover{opacity: 1;}</style>
    </head>
    <body onload="showsidebar();hidesidebar();showmenu()"> 
    <?php include "header.php";?>
  <div class="row" style="width:70%;margin:auto;margin-top: 80px;">
  <h1>About Us</h1>
  <p class="intro">
    Artisanal products are the products that are produced by artisans, either completely by hand or with the help of hand tools or even mechanical means, as long as the direct manual contribution of the artisan remains the most substantial component of the finished product.
    <br />
   These objects may be functional or strictly decorative, for example furniture, decorative art, sculpture, clothing, food items, household items, and tools and mechanisms such as the handmade clockwork movement of a watchmaker.  <br />
    <br />
 Artisans typically focus on producing high-quality, handcrafted goods rather than mass-produced items. This emphasis on quality can lead to a stronger sense of pride in one's work, as artisans often invest time and attention to detail to create something unique and long-lasting. 
  </p>
  <img src="images/couch1.jpg">
</div>
<div class="row" style="margin-top: 20px;">
<?php include "footer.php";?>
</div>
<script>
        function toggleAccountType() {
            $.ajax({
                type: "POST",
                url: window.location.href,
                data: { toggleAccountType: true },
                success: function(newAccountType) {
                    $('#accountType').text(newAccountType);
                }
            });
        }
    </script>
</body>
</html>













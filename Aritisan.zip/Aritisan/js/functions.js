function showmenu(){
    $("#collection").click(function(){
        $("#menulist").slideToggle();
    });
}
var mySidebar = document.getElementById("mySidebar");
var overlayBg = document.getElementById("myOverlay");
function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}
function showsidebar(){
  $("#bars2").click(function(){
      $("#leftmenuhide").slideDown();
  });
}
function hidesidebar(){
  $("#times").click(function(){
      $("#leftmenuhide").slideUp();
  });
}

